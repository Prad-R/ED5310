import csv
import matplotlib.pyplot as plt
import numpy as np

n = np.arange(4, 101, 1)
nlogn = n * np.emath.logn(2, n)

filename = "./src/Testing_and_Visualisation/Saved_Data/time.txt"

O2 = []
O4 = []

with open (filename, 'r') as file:

    csv_reader = csv.reader(file, delimiter = ' ')

    for row in csv_reader:

        O4.append(int(row[0]))
        O2.append(int(row[1]))

plt.figure(figsize = (10, 7.5))
plt.scatter(n, O2, label = "$O(n^2) =$ Ear Clipping Algorithm", color = 'g')
plt.scatter(n, O4, label = "$O(n^4) =$ Naive Algorithm", color = 'r')
plt.scatter(n, nlogn, color = 'b', label = "$O(nlog(n)) =$ Fast Algorithm")
plt.legend()
plt.grid()
plt.xticks(np.arange(0, 110, 10))
plt.xlabel("$n \\longrightarrow$", fontsize = 15)
plt.ylabel("Run Time (in ms) $\\longrightarrow$", fontsize = 15)
plt.title("Run Time Complexity of the Algorithsm", fontsize = 18)
plt.savefig("./src/Testing_and_Visualisation/Complexity.png")
plt.show()