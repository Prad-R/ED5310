The link to the video is given here : https://drive.google.com/file/d/17-DLspEBnhrYIINHARN-uyk8NwAtes85/view?usp=sharing

At 13:00, I run the program and show the plots of the polygon visualisation, but since the recording is only for the window, the pop-up matplotlib window has not been recorded. It can be visualised by running the command from your device. I have attached separate video files for the same here : https://drive.google.com/file/d/13GtIXyrPL5bGakkaxInGwBmvf3VyDZ_E/view?usp=sharing

Please refer to the video and the code comments for more insight into how the program works.
